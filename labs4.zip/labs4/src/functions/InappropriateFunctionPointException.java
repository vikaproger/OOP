/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package functions;
//исключение, выбрасываемое при попытке добавления или изменения точки функции 
//несоответствующим образом, наследует от класса Exception
/**
 *
 * @author vlad
 */
public class InappropriateFunctionPointException extends Exception {
    
}
